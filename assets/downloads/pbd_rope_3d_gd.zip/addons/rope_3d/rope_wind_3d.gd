@tool
class_name RopeWind3D extends Resource

## The wind force vector. If equal to Vector3.ZERO, wind will have a randomly changing direction.
@export_custom(PROPERTY_HINT_NONE, "suffix:N") var force := Vector3.ZERO
@export var noise: FastNoiseLite
@export var strength := 1.0
@export var time_scale := 1.0

func _init() -> void:
	noise = FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	noise.frequency = 0.05

## Samples the wind force at the given world-space position and time.
func sample(position := Vector3.ZERO, time := 0.0) -> Vector3:
	if not noise:
		return force * strength
	if force == Vector3.ZERO:
		return get_noise_vector(position, time) * strength
	var n = noise.get_noise_3d(position.x, position.y, position.z + time * time_scale)
	return force * strength * ((n + 1.0) * 0.5)

func get_noise_vector(position: Vector3, time: float) -> Vector3:
	var x = noise.get_noise_3d(
		position.x,
		position.y,
		position.z + time * time_scale
	)
	var y = noise.get_noise_3d(
		position.x + 1000.0,
		position.y + 1000.0,
		position.z + 1000.0 + time * time_scale
	)
	var z = noise.get_noise_3d(
		position.x + 2000.0,
		position.y + 2000.0,
		position.z + 2000.0 + time * time_scale
	)
	return Vector3(x, y, z)

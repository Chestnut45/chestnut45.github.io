@tool
@icon("res://addons/rope_3d/rope_attachment_3d.svg")
class_name RopeAttachment3D extends Node3D

enum Mode {
	FOLLOW,
	ANCHOR,
}

enum SnapMode {
	NONE,
	SEGMENT,
	PARTICLE
}

@export var mode := Mode.FOLLOW:
	set(value):
		if mode == value:
			return
		mode = value
		update_masses = true

@export var snap_mode := SnapMode.NONE:
	set(value):
		if snap_mode == value:
			return
		snap_mode = value
		if mode == Mode.ANCHOR:
			update_masses = true

@export_range(0.0, 1.0, 0.001) var t: float:
	set(value):
		if t == value:
			return
		t = value
		if mode == Mode.ANCHOR:
			update_masses = true

var update_masses := false

func update(rope: PBDRope3D_GD) -> void:
	if update_masses:
		rope.masses_dirty = true
		update_masses = false
	
	if mode == Mode.ANCHOR or not rope:
		# NOTE: See PBDRope3D_GD.update_simulation for anchor implementation
		# Anchors have to be applied at a different time during the simulation than follow mode
		# attachments, so it is not feasible for the implementation to live here.
		return
	
	match snap_mode:
		SnapMode.NONE:
			global_transform = rope.get_transform_at(t)
		SnapMode.SEGMENT:
			var scaled_t := minf(int(t * rope.segment_count), rope.segment_count - 1)
			var snapped_t := (scaled_t + 0.5) / rope.segment_count
			global_transform = rope.get_transform_at(snapped_t)
		SnapMode.PARTICLE:
			var snapped_t: float = roundf(t * rope.segment_count) / rope.segment_count
			global_transform = rope.get_transform_at(snapped_t)

@tool
@icon("res://addons/rope_3d/rope_3d.svg")
class_name PBDRope3D_GD extends MultiMeshInstance3D

#region Constants
## See [member simulation_flags] for descriptions of each flag's behaviour.
enum SimulationFlag {
	GAME = 1 << 0,
	EDITOR = 1 << 1,
	SELECTED = 1 << 2,
	BAKE_POSITIONS = 1 << 3
}

enum CollisionMode {
	## No collision detection is performed. Fastest mode.
	NONE,
	## Collision detection is performed once per simulation update, after constraint projection.
	## Significantly faster than Accurate mode, but may tunnel through solid geometry
	## at high speeds, or fail to wrap around solid geometry consistently.
	FAST, 
	## Collision detection is performed per solver iteration in step with constraint projection.
	## Slower than Fast mode, but much more resistent to tunnelling and wrapping issues.
	ACCURATE
}

enum CollisionType {
	## Collision detection is performed as raycasts through each particle to the rope's
	## surface in the direction of motion. Significantly faster than Sphere mode, and much more
	## resistant to velocity-based tunnelling, but allows more surface penetration, and cannot
	## be pushed by moving geometry.
	RAYCAST,
	## Collision detection is performed as swept sphere intersections for each particle.
	## Completely prevents particle penetration, and can be pushed by moving geometry, but
	## is slower than Raycast mode, and more susceptible to tunneling through small geometry.
	## Minimal clipping at the center of long segments is still expected.
	SPHERE,
}
#endregion

#region Exported Properties
@export_tool_button("Rebuild Rope") var reset_btn = rebuild

@export_custom(PROPERTY_HINT_NONE, "suffix:m")
var length := 3.0:
	set(value):
		if fixed_segment_length:
			length = max(segment_rest_length, round(value / segment_rest_length) * segment_rest_length)
			update_segment_count()
		else:
			length = max(0.01, value)
			update_segment_rest_length()
		mesh_dirty = true

@export_custom(PROPERTY_HINT_NONE, "suffix:m")
var radius := 0.1:
	set(value):
		radius = max(0.01, value)
		sphere_shape.radius = radius
		mesh_dirty = true

@export_custom(PROPERTY_HINT_NONE, "suffix:kg")
var particle_mass := 0.1:
	set(value):
		particle_mass = max(0.001, value)
		masses_dirty = true

@export_range(0.001, 1.0, 0.001)
var stiffness := 1.0:
	set(value):
		stiffness = value
		update_k()

@export_group("Anchor")
@export var anchor_start := true:
	set(value):
		anchor_start = value
		masses_dirty = true

@export var use_rotation := false:
	set(value):
		use_rotation = value
		masses_dirty = true

@export_group("Segments")
@export_range(1, 512, 1)
var segment_count := 10:
	set(value):
		segment_count = value
		if fixed_segment_length:
			update_length()
		else:
			update_segment_rest_length()
		dirty = true

@export_custom(PROPERTY_HINT_NONE, "suffix:m")
var segment_rest_length := 0.3:
	set(value):
		segment_rest_length = max(0.001, value)
		update_length()
		mesh_dirty = true

@export var fixed_segment_length := false

@export_group("Simulation")
@export var simulation_paused := false

## [b]Game:[/b] The rope will simulate in game.[br][br]
## [b]Editor:[/b] The rope will simulate in the editor.[br][br]
## [b]Selected:[/b] The rope will only simulate in the editor if it's currently selected.
## Has no effect if [constant SimulationFlag.EDITOR] is not set.[br][br]
## [b]Bake Positions:[/b] Rope particle positions will be serialized when saving scenes.
## If this flag is [i]not[/i] set, the rope will be rebuilt on [method _ready].
@export_flags("Game", "Editor", "Selected", "Bake Positions")
var simulation_flags := SimulationFlag.GAME | SimulationFlag.EDITOR:
	set(value):
		simulation_flags = value
		notify_property_list_changed()

@export_custom(PROPERTY_HINT_NONE, "suffix:s")
var simulation_delta := 0.0167:
	set(value):
		simulation_delta = clampf(value, 0.0, 1.0)
		update_damping_factor()

@export_range(1, 64, 1)
var solver_iterations := 4:
	set(value):
		solver_iterations = value
		update_k()

@export_group("Collision")
@export var collision_mode := CollisionMode.ACCURATE
@export var collision_type := CollisionType.RAYCAST
@export_flags_3d_physics var collision_mask := 1

@export_range(0.0, 1.0, 0.001)
var contact_damping := 0.98:
	set(value):
		contact_damping = value
		update_damping_factor()

@export_group("Forces")
@export var wind: RopeWind3D = null

@export_custom(PROPERTY_HINT_NONE, "suffix:m/s²")
var gravity_acceleration := Vector3.DOWN * 9.81

@export_group("Visuals")
@export var segment_mesh_override: Mesh:
	set(value):
		segment_mesh_override = value
		mesh_dirty = true

@export var segment_overlap := 0.0:
	set(value):
		segment_overlap = value
		mesh_dirty = true

@export_range(0, 10, 1)
var segment_cap_rings := 0:
	set(value):
		segment_cap_rings = value
		mesh_dirty = true

@export_range(4, 32, 1)
var radial_segments := 4:
	set(value):
		radial_segments = value
		mesh_dirty = true
#endregion

#region Internal Members
var elapsed := 0.0
var k: float
var damping_factor: float

## NOTE: Positions are only serialized when SimulationFlag.BAKE_POSITIONS is set.
## See [method _validate_property] for implementation.
var positions: PackedVector3Array
var predicted: PackedVector3Array
var velocities: PackedVector3Array
var inverse_masses: PackedFloat32Array
var damping_factors: PackedFloat32Array
var segment_orientations: PackedVector4Array

var attachments: Array[RopeAttachment3D]

var dirty := false
var mesh_dirty := false
var masses_dirty := false
var attachments_dirty := false
var updating := false

static var ray_query := PhysicsRayQueryParameters3D.new()
var shape_query := PhysicsShapeQueryParameters3D.new()
var sphere_shape := SphereShape3D.new()
#endregion

#region Public API
## Returns the global space Transform3D at the given normalized position along the rope.
func get_transform_at(t: float) -> Transform3D:
	var scaled := t * segment_count
	var i := int(scaled)
	if i == segment_count:
		i -= 1
	var p0 := positions[i]
	var p1 := positions[i + 1]
	var pos := lerp(p0, p1, scaled - i) as Vector3
	var v := segment_orientations[i]
	var orientation := Quaternion(v.x, v.y, v.z, v.w)
	return Transform3D(Basis(orientation), pos)
#endregion

#region Overrides
func _ready() -> void:
	shape_query.shape = sphere_shape
	sphere_shape.radius = radius
	
	update_k()
	update_damping_factor()
	
	multimesh = MultiMesh.new()
	multimesh.instance_count = 0
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	
	if simulation_flags & SimulationFlag.BAKE_POSITIONS:
		rebuild_baked()
	else:
		rebuild()

func _physics_process(delta: float) -> void:
	if simulation_paused or simulation_delta <= 0.0:
		return
	if Engine.is_editor_hint():
		if not simulation_flags & SimulationFlag.EDITOR:
			return
		if simulation_flags & SimulationFlag.SELECTED:
			# NOTE: Accessing EditorInterface statically isn't allowed in exported projects
			var interface = Engine.get_singleton(&"EditorInterface")
			if interface and self not in interface.get_selection().get_selected_nodes():
				return
	else:
		if not simulation_flags & SimulationFlag.GAME:
			return
	
	if dirty:
		rebuild()
	if attachments_dirty:
		rebuild_attachments()
	if masses_dirty:
		regenerate_particle_masses()
	
	update_simulation()
	update_mesh()
	elapsed += delta

func _validate_property(property: Dictionary) -> void:
	# Hides the multimesh property from the editor and avoids storing it in order to
	# avoid editor errors. See https://github.com/godotengine/godot/issues/106950
	# (Multimesh is also managed internally so even if the above issue is fixed, this should stay.
	# See segment_mesh_override if you want to use a custom mesh for each rope segment.)
	if property.name == "multimesh":
		property.usage = PROPERTY_USAGE_NONE
	
	# Only serialize positions when the flag is set
	if property.name == "positions":
		if simulation_flags & SimulationFlag.BAKE_POSITIONS:
			property.usage = PROPERTY_USAGE_STORAGE
		else:
			property.usage = PROPERTY_USAGE_NONE

func _notification(what: int) -> void:
	if what == NOTIFICATION_CHILD_ORDER_CHANGED:
		attachments_dirty = true
#endregion

#region Simulation
func update_simulation() -> void:
	var particle_count := segment_count + 1
	
	# Apply forces and predict next positions
	for i in range(particle_count):
		if inverse_masses[i] == 0.0:
			continue
		var velocity := velocities[i]
		velocity += gravity_acceleration * simulation_delta
		if wind:
			velocity += wind.sample(positions[i], elapsed) * inverse_masses[i] * simulation_delta
		velocity *= damping_factors[i]
		velocities[i] = velocity
		damping_factors[i] = 1.0
		predicted[i] = positions[i] + velocity * simulation_delta
	
	# Apply base rope anchors
	if anchor_start:
		predicted[0] = global_position
	else:
		global_position = positions[0]
	if use_rotation:
		predicted[1] = global_position + global_basis.z * segment_rest_length
	
	# Apply attachment anchors
	for attachment in attachments:
		if attachment.mode != RopeAttachment3D.Mode.ANCHOR:
			continue
		var scaled := attachment.t * segment_count
		var i := int(scaled)
		if i == segment_count:
			i -= 1
		var c := attachment.global_position
		var d := attachment.global_basis.z * segment_rest_length
		var rel_t := scaled - i
		match attachment.snap_mode:
			RopeAttachment3D.SnapMode.NONE:
				predicted[i] = c - d * rel_t
				predicted[i + 1] = c + d * (1 - rel_t)
			RopeAttachment3D.SnapMode.SEGMENT:
				predicted[i] = c - d * 0.5
				predicted[i + 1] = c + d * 0.5
			RopeAttachment3D.SnapMode.PARTICLE:
				predicted[roundi(scaled)] = c
	
	# Project constraints and resolve collisions
	match collision_mode:
		CollisionMode.NONE:
			for iter in range(solver_iterations):
				for i in range(segment_count):
					project_segment(i, i + 1)
		CollisionMode.FAST:
			for iter in range(solver_iterations):
				for i in range(segment_count):
					project_segment(i, i + 1)
			for i in range(particle_count):
				solve_collisions(i)
		CollisionMode.ACCURATE:
			for iter in range(solver_iterations):
				for i in range(segment_count):
					project_segment(i, i + 1)
					solve_collisions(i)
				solve_collisions(segment_count)
	
	# Update velocities and commit positions
	for i in range(particle_count):
		velocities[i] = (predicted[i] - positions[i]) / simulation_delta
		positions[i] = predicted[i]
	
	# Update attachments to follow new locations immediately
	for attachment in attachments:
		attachment.update(self)

# Solve the distance constraint between segment (i, j)
func project_segment(i: int, j: int):
	var p1 := predicted[i]
	var p2 := predicted[j]
	var segment := p2 - p1
	var segment_length := segment.length()
	if segment_length == 0.0:
		return
	
	var w1 := inverse_masses[i]
	var w2 := inverse_masses[j]
	var w_sum := w1 + w2
	if w_sum == 0.0:
		return
	
	var difference := (segment_length - segment_rest_length) / segment_length
	var correction := segment * difference * k
	predicted[i] += correction * w1 / w_sum
	predicted[j] -= correction * w2 / w_sum

# Resolve collisions for particle i
func solve_collisions(i: int) -> void:
	# TODO: Ignore collisions (early out) for infinite mass particles? May not be desirable...
	var from := positions[i]
	var to := predicted[i]
	var delta := to - from
	var dist := delta.length()
	if dist < 0.0001:
		return
	
	var dir := delta / dist
	var space_state = get_world_3d().direct_space_state
	
	match collision_type:
		CollisionType.RAYCAST:
			ray_query.collision_mask = collision_mask
			ray_query.from = from - dir * radius
			ray_query.to = to + dir * radius
			var hit := space_state.intersect_ray(ray_query)
			if hit:
				var n: Vector3 = hit.normal
				predicted[i] = from + dir.slide(n) * dist
				damping_factors[i] = damping_factor
		
		CollisionType.SPHERE:
			shape_query.collision_mask = collision_mask
			shape_query.transform.origin = from
			shape_query.motion = delta
			var safe := space_state.cast_motion(shape_query)
			if safe[0] < 1.0:
				var impact := from + delta * safe[1]
				var remaining := delta * (1.0 - safe[0])
				shape_query.transform.origin = impact
				var rest := space_state.get_rest_info(shape_query)
				if not rest.is_empty():
					var normal: Vector3 = rest.normal
					predicted[i] = from + delta * safe[0] + remaining.slide(normal)
					damping_factors[i] = damping_factor
					return
			
			shape_query.transform.origin = to
			var hit := space_state.get_rest_info(shape_query)
			if not hit.is_empty():
				var point: Vector3 = hit.point
				var normal: Vector3 = hit.normal
				var pen := radius - (to - point).length()
				if pen > 0.001:
					predicted[i] = to + normal * pen
					damping_factors[i] = damping_factor
#endregion

#region Rebuild & Mesh Update Methods
func rebuild() -> void:
	var particle_count := segment_count + 1
	positions.resize(particle_count)
	predicted.resize(particle_count)
	velocities.resize(particle_count)
	inverse_masses.resize(particle_count)
	damping_factors.resize(particle_count)
	segment_orientations.resize(segment_count)
	segment_orientations.fill(Vector4(0, 0, 0, 1))
	
	var rng := RandomNumberGenerator.new()
	rng.seed = 12345
	for i in range(particle_count):
		var pos := global_position + Vector3(rng.randf(), rng.randf(), rng.randf()) * 0.001
		positions[i] = pos
		predicted[i] = pos
		velocities[i] = Vector3.ZERO
		damping_factors[i] = 1.0
	
	regenerate_particle_masses()
	rebuild_mesh()
	update_mesh()
	dirty = false

func rebuild_baked() -> void:
	var n := positions.size()
	assert(n > 0, "Rope is in baked simulation mode but has no saved positions!")
	predicted.resize(n)
	velocities.resize(n)
	inverse_masses.resize(n)
	damping_factors.resize(n)
	segment_orientations.resize(segment_count)
	segment_orientations.fill(Vector4(0, 0, 0, 1))
	
	for i in range(n):
		predicted[i] = positions[i]
		velocities[i] = Vector3.ZERO
		damping_factors[i] = 1.0
	
	regenerate_particle_masses()
	rebuild_mesh()
	update_mesh()
	dirty = false

func regenerate_particle_masses() -> void:
	var particle_inv_mass = 1.0 / particle_mass
	inverse_masses[0] = 0.0 if anchor_start else particle_inv_mass
	inverse_masses[1] = 0.0 if use_rotation else particle_inv_mass
	for i in range(2, segment_count + 1):
		inverse_masses[i] = particle_inv_mass
	
	for attachment in attachments:
		if attachment.mode != RopeAttachment3D.Mode.ANCHOR:
			continue
		var scaled := attachment.t * segment_count
		var i := int(scaled)
		if i == segment_count:
			i -= 1
		match attachment.snap_mode:
			RopeAttachment3D.SnapMode.NONE, \
			RopeAttachment3D.SnapMode.SEGMENT:
				inverse_masses[i] = 0.0
				inverse_masses[i + 1] = 0.0
			RopeAttachment3D.SnapMode.PARTICLE:
				inverse_masses[roundi(scaled)] = 0.0
	
	masses_dirty = false

func rebuild_attachments() -> void:
	attachments.clear()
	for c in get_children():
		if c is RopeAttachment3D:
			attachments.push_back(c)
	masses_dirty = true

func rebuild_mesh() -> void:
	multimesh.instance_count = segment_count
	multimesh.visible_instance_count = segment_count
	if segment_mesh_override:
		multimesh.mesh = segment_mesh_override
	else:
		var capsule := CapsuleMesh.new()
		capsule.radius = radius
		capsule.height = segment_rest_length + 2 * radius + segment_overlap
		capsule.radial_segments = radial_segments
		capsule.rings = segment_cap_rings
		multimesh.mesh = capsule
	mesh_dirty = false

func update_mesh() -> void:
	if mesh_dirty:
		rebuild_mesh()
	
	var inv_global := global_transform.affine_inverse()
	var v := segment_orientations[0]
	var orientation := Quaternion(v.x, v.y, v.z, v.w)
	for i in range(segment_count):
		var p0 := positions[i]
		var p1 := positions[i + 1]
		var pos := (p0 + p1) * 0.5
		var segment := p1 - p0
		var current_length := segment.length()
		if current_length <= 0.001:
			continue
		
		var tangent := segment / current_length
		var prev_tangent := orientation * Vector3.DOWN
		var q_rot := Quaternion(prev_tangent, tangent)
		orientation = (q_rot * orientation).normalized()
		segment_orientations[i] = Vector4(orientation.x, orientation.y, orientation.z, orientation.w)
		
		var factor := Vector3(1, current_length / segment_rest_length, 1)
		var t := Transform3D(Basis(orientation), pos).scaled_local(factor)
		multimesh.set_instance_transform(i, inv_global * t)
#endregion

#region Property Dependencies
# NOTE: The updating flag is only required here to avoid infinite recursion between
# properties that have bidirectional dependencies, due to how GDScript setters work.
func update_k() -> void:
	if updating:
		return
	updating = true
	k = 1.0 - pow(1.0 - stiffness, 1.0 / solver_iterations)
	updating = false

func update_length() -> void:
	if updating:
		return
	updating = true
	length = segment_rest_length * segment_count
	updating = false

func update_segment_count() -> void:
	if updating:
		return
	updating = true
	segment_count = round(length / segment_rest_length)
	updating = false

func update_segment_rest_length() -> void:
	if updating:
		return
	updating = true
	segment_rest_length = length / segment_count
	updating = false

func update_damping_factor() -> void:
	if updating:
		return
	updating = true
	damping_factor = pow(1.0 - contact_damping, simulation_delta)
	updating = false
#endregion
